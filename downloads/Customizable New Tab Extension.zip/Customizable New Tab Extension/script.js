const container = document.getElementById("typewriter-container");
const searchInput = document.querySelector(".search-txt");
const searchButton = document.querySelector(".search-btn");

// change main text here
let texts = [
  "drapinqs ⛧",
  "syringe 狗",
  "drain ⸸",
];

const text = texts[Math.floor(Math.random() * texts.length)];

const typingSpeed = Math.floor(Math.random() * 25) + 35; // change typewriter speed

function* iterateChars(str) {
  for (let i = 0; i < str.length; i++) {
    const char = str[i];

    if (char.match(/[\uD800-\uDBFF]/) && str[i + 1]) {
      const surrogatePair = char + str[++i];
      yield surrogatePair;
    } else {
      yield char;
    }
  }
}

const typeWriter = (text, container, iterator) => {
  const { value, done } = iterator.next();

  if (!done) {
    container.innerHTML += value;
    container.setAttribute("data-content", container.innerHTML);
    setTimeout(() => typeWriter(text, container, iterator), typingSpeed);
  } else {
    addCursor(container);
  }
};

const addCursor = (container) => {
  const span = document.createElement("span");
  span.classList.add("cursor", "blurred-text");

  span.innerHTML = "|"; // remove this if you don't want the blinking typewriter line

  span.setAttribute("data-content", span.innerHTML);
  container.appendChild(span);
};

const iterator = iterateChars(text);
typeWriter(text, container, iterator);

// search button
function searchGoogle() {
  const query = searchInput.value;
  if (query.trim() !== "") {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`; // change search engine of search button 
    window.location.href = searchUrl;
  }
}

searchButton.addEventListener("click", searchGoogle);
searchInput.addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    searchGoogle();
  }
});
